<?php
for ($i = 1; $i <= 100; $i++) {
    echo "Square of $i is " . ($i * $i) . "<br>";
}
?>


