<?php
$count = 10;
while ($count >= 1) {
    echo $count . "<br>";
    $count--;
}
?>
